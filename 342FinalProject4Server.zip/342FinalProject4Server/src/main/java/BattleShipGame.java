import java.io.Serializable;

public class BattleShipGame implements Serializable {
    static final long serialVersionUID = 42L;
    Boolean versusComputer;
    Player currentPlayer;
    Player opponent;
    Computer computerPlayer;
    int countShipSize;
    boolean isShipFilled;
    boolean firstConnect;
    boolean otherPlayerConnected;
    Boolean above; //this means that they can choose spots above the coordinate they chose
    Boolean below; //this means that they can choose spots below the coordinate they chose
    Boolean right; //this means that they can choose spots to the right of the coordinate they chose
    Boolean left; //this means that they can choose spots to the left of the coordinate they chose

    BattleShipGame(){
        countShipSize = 0;
        isShipFilled = false;
        versusComputer = false;
        currentPlayer = new Player();
        opponent = new Player();
        computerPlayer = new Computer();
        firstConnect = false;
        otherPlayerConnected = false;
        above = true;
        below = true;
        right = true;
        left = true;
    }
    public String checkWinner(){
        if (versusComputer){
            if(computerPlayer.computerHealth == 0){
                return "currentPlayer";
            }
            else if(currentPlayer.playerHealth == 0){
                return "otherPlayer";
            }
        }
        else {
            if (opponent.playerHealth == 0) {
                return "currentPlayer";
            }
            else if (currentPlayer.playerHealth == 0) {
                return "otherPlayer";
            }
        }
        return "none";
    }

    public Boolean checkAttack(String coordinate, Boolean isComputerTurn){
        //computer is attacking the player
        if (!versusComputer) {
            if (opponent.allCoordinates.contains(coordinate)) {
                if (opponent.twoShip.getCoordinates().contains(coordinate)) {
                    opponent.twoShip.hitCount++;
                }
                else if (opponent.threeShip.getCoordinates().contains(coordinate)) {
                    opponent.threeShip.hitCount++;
                }
                else if (opponent.threeShip2.getCoordinates().contains(coordinate)) {
                    opponent.threeShip2.hitCount++;
                }
                else if (opponent.fourShip.getCoordinates().contains(coordinate)) {
                    opponent.fourShip.hitCount++;
                }
                else if (opponent.fiveShip.getCoordinates().contains(coordinate)) {
                    opponent.fiveShip.hitCount++;
                }
                opponent.playerHealth--;
                return true;
            }

        }
        else {
            if (isComputerTurn) {
                //check the player's coordinates to check if the computer hit any of their ships
                if (currentPlayer.allCoordinates.contains(coordinate)){
                    if (currentPlayer.twoShip.getCoordinates().contains(coordinate)) {
                        currentPlayer.twoShip.hitCount++;
                    }
                    else if (currentPlayer.threeShip.getCoordinates().contains(coordinate)) {
                        currentPlayer.threeShip.hitCount++;
                    }
                    else if (currentPlayer.threeShip2.getCoordinates().contains(coordinate)) {
                        currentPlayer.threeShip2.hitCount++;
                    }
                    else if (currentPlayer.fourShip.getCoordinates().contains(coordinate)) {
                        currentPlayer.fourShip.hitCount++;
                    }
                    else if (currentPlayer.fiveShip.getCoordinates().contains(coordinate)) {
                        currentPlayer.fiveShip.hitCount++;
                    }
                    currentPlayer.playerHealth--;
                    return true;
                }
            }
            //player is attacking the computer
            else {
                if (computerPlayer.allCoordinates.contains(coordinate)) {
                    if (computerPlayer.twoShip.getCoordinates().contains(coordinate)) {
                        computerPlayer.twoShip.hitCount++;
                    } else if (computerPlayer.threeShip.getCoordinates().contains(coordinate)) {
                        computerPlayer.threeShip.hitCount++;
                    } else if (computerPlayer.threeShip2.getCoordinates().contains(coordinate)) {
                        computerPlayer.threeShip2.hitCount++;
                    } else if (computerPlayer.fourShip.getCoordinates().contains(coordinate)) {
                        computerPlayer.fourShip.hitCount++;
                    } else if (computerPlayer.fiveShip.getCoordinates().contains(coordinate)) {
                        computerPlayer.fiveShip.hitCount++;
                    }
                    computerPlayer.computerHealth--;
                    return true;
                }
            }
        }

        return false;
    }
    public void randomizeCoords(Ship ship){
        ship.isHorizontal = false;
        ship.isVertical = false;
        String randCoord = "";
        String[] letters = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};
        String[] orientation = {"Horizontal", "Vertical"};
        int rangeForNums = 10; //range for choosing random numbers for coord (upperBound - lowerBound)
        int rangeForLetters = 10; //range for choosing for random letters(index in array)
        int rangeForOrientation = 2;
        int randomOrientation = 0;
        //keep looping generating random coordinate until one works where we can fill all spots for ship
        randomOrientation = (int)(Math.random() * rangeForOrientation);
        if (orientation[randomOrientation].equals("Horizontal")) {
            ship.isHorizontal = true;
        }
        else {
            ship.isVertical = true;
        }

        while (ship.getCoordinates().size() != ship.shipLength-1) {
            int randomNum = (int)(Math.random() * rangeForNums) + 1;
            int randomLetter = (int)(Math.random() * rangeForLetters);
            randCoord = letters[randomLetter] + randomNum;
            checkFirstClick(randCoord, ship, versusComputer);

        }

        ship.addCoordinates(randCoord); //add first initial coord if valid
        computerPlayer.allCoordinates.add(randCoord);
        
    }
    public void createBoardForComputer() {
        randomizeCoords(computerPlayer.twoShip);
        randomizeCoords(computerPlayer.threeShip);
        randomizeCoords(computerPlayer.threeShip2);
        randomizeCoords(computerPlayer.fourShip);
        randomizeCoords(computerPlayer.fiveShip);
    }

    public void checkAbove(Ship ship, char rowChar, Integer col, Boolean isComputer){
        countShipSize = 0;
        for (int i = 0; i < ship.shipLength - 1; i++){
            char nextCoord = (char)(rowChar - (i+1));
            
            String fullCoord = String.valueOf(nextCoord) + String.valueOf(col);
            
            //check if this coordinate exists in the array
            if (!isComputer){
                if (currentPlayer.allCoordinates.contains(fullCoord)) {
                    //ship cannot be placed above
                    above = false;
                    break;
                }
            }
            else{
                if (computerPlayer.allCoordinates.contains(fullCoord)) {
                    //ship cannot be placed above
                    above = false;
                    break;
                }
            }

            //if we have not filled up all the spots for the ship, add next coordinate
            if (countShipSize < ship.shipLength - 1){
                countShipSize++;
                ship.addCoordinates(fullCoord);
            }
        }
    }

    public void checkBelow(Ship ship, char rowChar, Integer col, Boolean isComputer){
        for (int i = 0; i < ship.shipLength - 1; i++) {
            char nextCoord = (char)(rowChar + (i+1));
            String fullCoord = String.valueOf(nextCoord) + String.valueOf(col);

            //check if this coordinate exists in the array
            if (!isComputer){
                if (currentPlayer.allCoordinates.contains(fullCoord)) {
                    //ship cannot be placed below
                    below = false;
                    break;
                }
            }
            else {
                if (computerPlayer.allCoordinates.contains(fullCoord)) {
                    //ship cannot be placed below
                    below = false;
                    break;
                }
            }

            //if we have not filled up all the spots for the ship, add next coordinate
            if (countShipSize < ship.shipLength - 1) {
                countShipSize++;
                ship.addCoordinates(fullCoord);
            }
        }
    }

    public void checkLeft(Ship ship, char rowChar, Integer col, Boolean isComputer){
        for(int i = 0; i < ship.shipLength -1; i++){
            int nextInt = col - (i+1);
            String fullCoord = String.valueOf(rowChar) + String.valueOf(nextInt);

            //check if this coordinate exists in the array
            if (!isComputer){
                if(currentPlayer.allCoordinates.contains(fullCoord)){
                    left = false;
                    break;
                }
            }
            else{
                if(computerPlayer.allCoordinates.contains(fullCoord)){
                    left = false;
                    break;
                }
            }

            //if we have not filled up all the spots for the ship, add next coordinate
            if(countShipSize < ship.shipLength - 1){
                countShipSize++;

                ship.addCoordinates(fullCoord);
            }
        }
    }

    public void checkRight(Ship ship, char rowChar, Integer col, Boolean isComputer){

        for (int i = 0; i < ship.shipLength -1; i++) {
            int nextInt = col +(1+i);
            String fullCoord = String.valueOf(rowChar) + String.valueOf(nextInt);

            //check if this coordinate exists in the array
            if (!isComputer) {
                if (currentPlayer.allCoordinates.contains(fullCoord)) {

                    right = false;
                    break;
                }
            }
            else {
                if (computerPlayer.allCoordinates.contains(fullCoord)) {
                    
                    right = false;
                    break;
                }
            }

            //if we have not filled up all the spots for the ship, add next coordinate
            if(countShipSize < ship.shipLength - 1){
                countShipSize++;

                ship.addCoordinates(fullCoord);
            }
        }
    }

    //check users first click for ship to make sure they have room to fill in the rest of their ship
    public void checkFirstClick(String coord, Ship ship, Boolean isComputer) {
        Integer col = Integer.parseInt(coord.substring(1)); //corresponding coordinate number (col)
        char rowChar = coord.charAt(0); //convert string to char

        //checking out of bounds for vertical
        //if going below leads to it being out of bounds
        if ((ship.shipLength - 1) + rowChar > 'J') {
            below = false;
        }
        else if (rowChar - (ship.shipLength - 1) < 'A') {
            above = false;
        }

        //checking out of bounds for horizontal
        //if going below leads to it being out of bounds
        if (col + (ship.shipLength - 1) > 10) {
            right = false;
        }
        else if(col - (ship.shipLength - 1) < 1) {
            left = false;
        }

        //check based off the letters
        if (ship.isVertical) {
            //there is no available space above the coordinate

            if (above.equals(false)) {
                //they are both out of bounds, so ship will not fit
                if (below.equals(false)) {
                    above = true;
                    below = true;
                    isShipFilled = false;
                    countShipSize = 0;
                    ship.getCoordinates().clear();
                    ship.isHorizontal = false;
                    ship.isVertical = false;
                    return;
                }
                //there is available space only below the coordinate
                else {
                    // go below
                    checkBelow(ship, rowChar, col, isComputer);
                }

            }
            //there is available space above the coordinate
            else {
                //only available space above
                if (below.equals(false)) {
                    //checking for space above
                    checkAbove(ship,rowChar, col, isComputer);
                }
                //available space both above and below
                else {
                    checkBelow(ship, rowChar, col, isComputer);
                    if (countShipSize != ship.shipLength - 1) {
                        checkAbove(ship,rowChar, col, isComputer);
                    }
                }
            }
        }
        //check based off numbers if horizontal
        else {
           
            //there is no available space to the left of the coordinate
            if (left.equals(false)) {
                //they are both out of bounds, so ship will not fit
                if (right.equals(false)) {
                    left = true;
                    right = true;
                    isShipFilled = false;
                    countShipSize = 0;
                    ship.getCoordinates().clear();
                    ship.isHorizontal = false;
                    ship.isVertical = false;
                    return;
                }
                //there is available space only to the right the coordinate
                else {
                    // go right
                    checkRight(ship, rowChar, col, isComputer);
                }
            }
            //there is available space to the left the coordinate
            else {
                //available space only to the left
                if (right.equals(false)) {
                    //checking for space to the left
                    checkLeft(ship,rowChar, col, isComputer);
                }
                //available space both left and right
                else {
                    checkLeft(ship, rowChar, col, isComputer);
                    if (countShipSize != ship.shipLength - 1) {
                        checkRight(ship,rowChar, col, isComputer);
                    }
                }
            }
        }

        if (countShipSize == ship.shipLength - 1) {
            isShipFilled = true;

            if (!isComputer) {
                currentPlayer.allCoordinates.addAll(ship.getCoordinates());
            }
            else {
                computerPlayer.allCoordinates.addAll(ship.getCoordinates());
            }

        }
        else {
            ship.getCoordinates().clear();
            isShipFilled = false;
        }

        above = true;
        below = true;
        left = true;
        right = true;
        countShipSize = 0;
        ship.isHorizontal = false;
        ship.isVertical = false;
    }
}
