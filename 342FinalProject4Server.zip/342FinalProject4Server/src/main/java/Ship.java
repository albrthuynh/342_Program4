/**------------------------------------------
 Project 4: Battleship Game
 Course: CS 342, Spring 2024
 System: IntelliJ and Windows 11 and macOS
 Student Author: Dana Fakhreddine, Viviana Lopez, Karina Perez, Albert Huynh
 ---------------------------------------------**/
import java.util.*;

import java.util.HashMap;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import static javafx.scene.paint.Color.rgb;
import javafx.scene.image.Image;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicReference;
import javafx.scene.image.ImageView;
import javafx.stage.WindowEvent;
import java.io.Serializable;


import static javafx.scene.paint.Color.rgb;


public class Ship implements Serializable {
    static final long serialVersionUID = 42L;
    Boolean isHorizontal;
    Boolean isVertical;
    int shipLength;
    int hitCount;
    Boolean shipAlreadySunk;

    private ArrayList<String> coordinates;

    Ship(int shipLength){
        this.shipLength = shipLength;
        isHorizontal = false;
        isVertical = false;
        hitCount = 0;
        shipAlreadySunk = false;
        coordinates = new ArrayList<>();
    }

    public void addCoordinates (String coords){
        coordinates.add(coords);
    }

    public ArrayList<String> getCoordinates(){
        return coordinates;
    }
}
