/**------------------------------------------
 Project 4: Battleship Game
 Course: CS 342, Spring 2024
 System: IntelliJ and Windows 11 and macOS
 Student Author: Dana Fakhreddine, Viviana Lopez, Karina Perez, Albert Huynh
 ---------------------------------------------**/


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.scene.control.ListView;
/*
 * Clicker: A: I really get it    B: No idea what you are talking about
 * C: kind of following
 */

public class Server{

	int count = 1;	
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	TheServer server;
	private Consumer<Serializable> callback;

	Server(Consumer<Serializable> call){
	
		callback = call;
		server = new TheServer();
		server.start();
	}
	
	
	public class TheServer extends Thread{
		
		public void run() {
		
			try(ServerSocket mysocket = new ServerSocket(5555);){
		    System.out.println("Server is waiting for a client!");
			
		    while(true) {
		
				ClientThread c = new ClientThread(mysocket.accept(), count);
				callback.accept("client has connected to server: " + "client #" + count);
				clients.add(c);
				c.start();
				
				count++;
			    }
			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}
	

		class ClientThread extends Thread{
			Socket connection;
			int count;
			ObjectInputStream in;
			ObjectOutputStream out;
			BattleShipGame serverGame;

			ClientThread(Socket s, int count){
				this.connection = s;
				this.count = count;
				serverGame = new BattleShipGame();
			}

			public void run(){
					
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}

				 while (true) {
					    try {

					    	BattleShipGame data = (BattleShipGame) in.readObject();
							if (clients.size() == 2 && !data.otherPlayerConnected) {

								clients.get(0).serverGame.firstConnect = true;
								clients.get(0).serverGame.otherPlayerConnected = true;
								clients.get(0).serverGame.currentPlayer.currPlayerTurn = true; //the first client attacks first
								clients.get(0).serverGame.opponent = data.currentPlayer;
								clients.get(0).serverGame.currentPlayer.clientNumber = 1; //differentiating between player 1 and 2

								clients.get(0).out.reset();
								clients.get(0).out.writeObject(clients.get(0).serverGame);

								clients.get(1).serverGame.currentPlayer.allCoordinates = data.currentPlayer.allCoordinates;

								clients.get(1).serverGame.opponent = clients.get(0).serverGame.currentPlayer;

								clients.get(1).serverGame.firstConnect = true;

								clients.get(1).serverGame.currentPlayer.currPlayerTurn = false;

								clients.get(1).serverGame.otherPlayerConnected = true;

								clients.get(1).serverGame.currentPlayer.clientNumber = 2;

								clients.get(1).out.reset();
								clients.get(1).out.writeObject(clients.get(1).serverGame);
							}
							//rest of game
							else if (clients.size() == 2 && !data.firstConnect) {
								clients.get(0).serverGame.firstConnect = false;
								clients.get(1).serverGame.firstConnect = false;


								//if it is now the second clients turn, update its opponent and send to that
								// client to indicate it is now their turn
								//the if statement condition indicates that it was previously that clients turn
								if (clients.get(0).serverGame.currentPlayer.currPlayerTurn) {
									clients.get(0).serverGame.currentPlayer.currPlayerTurn = false;
									clients.get(1).serverGame.currentPlayer.currPlayerTurn = true; //client #1 turn

									clients.get(0).serverGame.opponent = data.opponent;
									clients.get(1).serverGame.opponent = data.currentPlayer;

									clients.get(1).serverGame.currentPlayer.playerHealth = data.opponent.playerHealth;

									clients.get(1).out.reset();
									clients.get(1).out.writeObject(clients.get(1).serverGame);

									clients.get(0).out.reset();
									clients.get(0).out.writeObject(clients.get(0).serverGame);
								}

								//if it is now the first clients turn, update its opponent and send to that
								// client to indicate it is now their turn
								else {
									clients.get(0).serverGame.firstConnect = false;
									clients.get(1).serverGame.firstConnect = false;
									clients.get(1).serverGame.currentPlayer.currPlayerTurn = false;
									clients.get(0).serverGame.currentPlayer.currPlayerTurn = true;

									clients.get(1).serverGame.opponent = data.opponent;
									clients.get(0).serverGame.opponent = data.currentPlayer;

									clients.get(0).serverGame.currentPlayer.playerHealth = data.opponent.playerHealth;

									clients.get(0).out.reset();
									clients.get(0).out.writeObject(clients.get(0).serverGame);
									clients.get(1).out.reset();
									clients.get(1).out.writeObject(clients.get(1).serverGame);
								}
							}

						}
					    catch (Exception e) {
							e.printStackTrace();
					    	callback.accept("OOOOPPs...Something wrong with the socket from client: " + count + "....closing down!");
					    	//updateClients("Client #"+count+" has left the server!");
					    	clients.remove(this);
					    	break;
					    }
					}
				}//end of run

			public void send(BattleShipGame data) {
				try {
					out.writeObject(data);
				}
				catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}//end of client thread

}


	
	

	
