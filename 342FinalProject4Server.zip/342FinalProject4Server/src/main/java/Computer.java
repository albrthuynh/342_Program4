/**------------------------------------------
 Project 4: Battleship Game
 Course: CS 342, Spring 2024
 System: IntelliJ and Windows 11 and macOS
 Student Author: Dana Fakhreddine, Viviana Lopez, Karina Perez, Albert Huynh
 ---------------------------------------------**/

import java.io.Serializable;
import java.util.ArrayList;
import java.util.*;

public class Computer implements Serializable {
    static final long serialVersionUID = 42L;

    ArrayList<String> allCoordinates;
    Ship twoShip;
    Ship threeShip;
    Ship threeShip2;
    Ship fourShip;
    Ship fiveShip;
    int computerHealth;

    Computer(){
        allCoordinates = new ArrayList<>();
        twoShip = new Ship(2);
        threeShip = new Ship(3);
        threeShip2 = new Ship(3);
        fourShip = new Ship(4);
        fiveShip = new Ship(5);
        computerHealth = 17;
    }

    public String computerHit(){
        String[] letters = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};

        int randomNum = (int)(Math.random() * 10) + 1;
        int randomLetter = (int) (Math.random() * 10);
        String fullCoord = letters[randomLetter] + randomNum;

        return fullCoord;
    }
}
