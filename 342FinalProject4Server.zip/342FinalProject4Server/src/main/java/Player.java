/**------------------------------------------
 Project 4: Battleship Game
 Course: CS 342, Spring 2024
 System: IntelliJ and Windows 11 and macOS
 Student Author: Dana Fakhreddine, Viviana Lopez, Karina Perez, Albert Huynh
 ---------------------------------------------**/
import java.io.Serializable;
import java.util.ArrayList;

public class Player implements Serializable {
    static final long serialVersionUID = 42L;
    ArrayList<String> allCoordinates;
    ArrayList<String> sentCoordinate;

    int clientNumber = 1;
    Ship twoShip;
    Ship threeShip;
    Ship threeShip2;
    Ship fourShip;
    Ship fiveShip;

    int playerHealth;
    Boolean currPlayerTurn = false;

    Player(){
        allCoordinates = new ArrayList<>();
        sentCoordinate = new ArrayList<>();
        playerHealth = 17;
        twoShip = new Ship(2);
        threeShip = new Ship(3);
        threeShip2 = new Ship(3);
        fourShip = new Ship(4);
        fiveShip = new Ship(5);
    }
}
